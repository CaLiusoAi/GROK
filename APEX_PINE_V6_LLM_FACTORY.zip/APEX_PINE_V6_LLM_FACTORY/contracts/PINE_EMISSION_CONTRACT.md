PINE EMISSION CONTRACT — paste this directly above any request for Pine code.
Keep it short on purpose. A 1,600-line spec gets forgotten by the time code is
written; this does not. Obey it literally.

────────────────────────────────────────────────────────────────────────────
BEFORE you write ANY Pine code, output these THREE things IN THIS ORDER.
If you cannot, say so and STOP. Do not emit code without all three.

STEP 1 — DETECTION CHECK (only if a chart/candle/setup is involved; else write “N/A”):
• Compute direction from the data yourself FIRST: close>open=Bullish,
close<open=Bearish, close==open=Neutral. State it in one line.
• If I labeled it differently, OVERRIDE me out loud:
“CONTRADICTION: you said X, the data is Y. Using Y.”
• If I named a pattern (doji, FVG, swing, etc.) and MORE THAN ONE candle on
the chart fits the basic shape, you must list every qualifier that makes
MINE the target — shape ratios, location, sequence, trigger — as numbers.
If more than one still qualifies, LIST them and ASK which. Never silently
pick one. “There are 6 dojis; only bar 14 is at the swing low” — that kind.

STEP 2 — THE HEADER, AS PINE COMMENTS, INSIDE THE CODE BLOCK:
The header is NOT a chat message and NOT a markdown table. It is // comment
lines that are the FIRST lines of the code block I will copy. Fill every
field with a REAL value — zero [placeholders] may survive. Minimum sections:

//@version=6
// ============================================================
// IDENTITY      : <name> | indicator/strategy | <date>
// REQUEST       : <my request in one sentence>
// ANSWERS       : <the ONE question this script answers>
// DOES NOT      : <what it deliberately leaves out>
// INPUTS        : <list>
// DETECTION     : <exact numeric rule for the target, from STEP 1>
// RESOURCE      : labels=N lines=N boxes=N tables=N  (real counts)
// INVARIANTS    : (list every rule THIS code relies on, e.g.)
//   INV-01 request.security lookahead_off, global
//   INV-02 every drawing handle var-init to na, guarded before set_*
//   INV-03 if-conditions are bool (close>open, not close)
//   INV-04 no fictional members (no line.style_none, no str.hash)
//   INV-05 one bgcolor/barcolor call, resolved to one color var
//   INV-06 confirmed-bar gating on signals (barstate.isconfirmed)
//   INV-07 fail-closed: missing data -> na / draw nothing
//   INV-0n <any rule specific to this script>
// LIMITS        : not compiled in TradingView; human must verify on chart
// ============================================================

STEP 3 — SELF-CHECK LINE (one line, out loud, before the code):
“Header: all fields filled, 0 placeholders. Detection: stated & numeric.
Invariants: N listed. Emitting now.”
If any part is missing, you may NOT emit code. Fix it or tell me what’s blocking.

────────────────────────────────────────────────────────────────────────────
HARD RULES WHILE WRITING THE CODE (the ones that keep breaking):
• Header lives INSIDE the code block, top, as comments. Never outside it.
• No line.style_none (doesn’t exist) — hide a line by not drawing/deleting it.
• No str.hash / SHA / hashing — Pine v6 has none. Use an int sequence if you
need an event log; say “hashing is external” if asked for a crypto ledger.
• var line/label/box x = na  →  guard “if not na(x)” before any x.set_*/delete.
• if <bool only>:  if close>open  (never  if close).
• Only color.rgb()/color.new() — no color.emerald/gold/teal etc.
• One statement per line. No semicolons. No smart quotes. No em-dashes in code.
• Draw current-state objects ONCE and update in place — never create-per-bar.
• Default visible: <=6 labels, <=1 table (<=6 rows). More goes behind toggles.

If you skip the header or the detection check, you have failed the task even if
the code compiles. Both come first. Always.
────────────────────────────────────────────────────────────────────────────