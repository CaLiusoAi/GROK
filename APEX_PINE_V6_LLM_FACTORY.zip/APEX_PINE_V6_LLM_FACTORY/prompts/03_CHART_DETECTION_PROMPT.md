# Chart or Candle Detection Prompt

Use this when a user supplies a chart image, candle data, or asks for pattern detection.

Before code, do this:

1. Determine candle direction from data, not user labels:
   - close > open means bullish
   - close < open means bearish
   - close == open means neutral
2. If the user's label conflicts with the data, state the contradiction.
3. If several bars fit the named pattern, list numeric qualifiers that isolate the target:
   - location
   - sequence
   - body ratio
   - wick ratio
   - volume condition
   - session or time filter
   - trigger condition
4. If multiple candidates still qualify, ask which one. Do not silently choose.
5. Only after detection is unambiguous, generate code.
