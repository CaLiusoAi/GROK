# Compile Error Repair Prompt

Use this after TradingView returns an error.

Here is the Pine v6 script:

```pine
<paste full script>
```

Here is the TradingView compiler error exactly:

<copy exact error and line number>

Repair rules:

1. Explain the error in one sentence.
2. Make the smallest correction that fixes it.
3. Preserve the original script's purpose and visuals.
4. Emit the full corrected script, not a patch.
5. Keep the header inside the code block.
6. Set compile status to NOT_RUN until I test it.
7. Do not invent Pine APIs.
