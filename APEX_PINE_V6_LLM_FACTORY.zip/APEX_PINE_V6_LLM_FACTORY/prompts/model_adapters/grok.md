# Grok Adapter

Paste LOAD_THIS_FIRST.md and prohibit improvisation. Require static gate output after code. Grok should be told directly that jokes do not substitute for Pine APIs existing.
