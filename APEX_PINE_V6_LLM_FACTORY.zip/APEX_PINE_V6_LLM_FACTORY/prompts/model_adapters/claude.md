# Claude Adapter

Paste LOAD_THIS_FIRST.md, then the request. Claude often handles long doctrine well, but final-output drift still happens. Repeat the hard bans immediately before code emission.
