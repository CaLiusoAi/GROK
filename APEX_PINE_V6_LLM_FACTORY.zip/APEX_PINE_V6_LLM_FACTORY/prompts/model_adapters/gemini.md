# Gemini Adapter

Paste LOAD_THIS_FIRST.md and keep the request concrete. Gemini benefits from explicit output format constraints. Restate: complete Pine v6 file only, header inside code, compile status NOT_RUN.
