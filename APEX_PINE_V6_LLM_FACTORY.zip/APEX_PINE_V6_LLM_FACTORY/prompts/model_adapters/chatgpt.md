# Chatgpt Adapter

Use LOAD_THIS_FIRST.md as the initial instruction block. Then paste the user request template. For complex builds, force phased mode and stop after each phase for TradingView verification. Keep the emission contract near the final code block.
