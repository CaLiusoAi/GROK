# User Request Template

Use this when asking any LLM to build Pine v6.

BUILD GOAL:
<describe the indicator or strategy in one paragraph>

SCRIPT TYPE:
indicator or strategy

ONE QUESTION THE SCRIPT ANSWERS:
<example: Is price sweeping prior session liquidity and reversing with confirmation?>

TIMEFRAME ASSUMPTIONS:
<chart timeframe, MTF sources if any>

VISUAL OUTPUT:
<plots, labels, lines, boxes, table, alerts>

RESOURCE LIMITS:
labels <= 6 visible by default, lines <= 20, boxes <= 20, tables <= 1 unless I explicitly ask for more.

TRADING RULES OR FORMULAS:
<exact formulas, thresholds, sessions, confirmation rules>

DO NOT INCLUDE:
<features to exclude>

BUILD MODE:
single-pass or phased

Use the APEX Pine v6 Factory rules. Emit complete Pine v6 code with the header inside the code block and compile status NOT_RUN.
