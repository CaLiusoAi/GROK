# Pine v6 Error Triage Prompt

Classify a TradingView compiler error into one of these repair lanes:

A. Fictional API or enum: replace with real Pine v6 construct or remove feature.
B. Type mismatch: make bool, int, float, color, string, line, label, box, or table type explicit.
C. Scope or series issue: move declaration, use var, or avoid illegal local call.
D. Object lifecycle issue: var-init to na, create once, guard mutation/delete with not na.
E. MTF issue: request.security discipline, lookahead_off, gaps behavior.
F. Visual density issue: reduce, toggle, or update in place.
G. Syntax issue: one statement per line, no semicolons, no smart quotes.
H. Unknown: preserve full error and ask for exact line context.

Repair only the lane that matches the compiler error.
