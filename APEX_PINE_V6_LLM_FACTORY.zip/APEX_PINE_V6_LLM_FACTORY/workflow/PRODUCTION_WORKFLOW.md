# Production Workflow

## Single-pass build

Use for small indicators, simple alerts, or clear strategy scaffolds.

1. Paste LOAD_THIS_FIRST.md into the model.
2. Paste the request template.
3. Require one complete Pine v6 file.
4. Run validators/pine_v6_static_gate.py locally if possible.
5. Paste into TradingView.
6. Record result in tracker/APEX_compile_tracker.xlsx.

## Phased build

Use for dashboards, MTF tools, liquidity maps, session systems, strategies, and anything with drawings.

1. Phase 1: header, inputs, basic plots.
2. Test in TradingView.
3. Phase 2: detection and calculations.
4. Test in TradingView.
5. Phase 3: drawings and labels.
6. Test in TradingView.
7. Phase 4: alerts or strategy entries.
8. Test in TradingView.
9. Final pass: visual density and cleanup.

## Repair loop

1. Copy exact TradingView error.
2. Use prompts/02_COMPILE_ERROR_REPAIR_PROMPT.md.
3. Repair the full script.
4. Test again.
5. Log pass/fail and any unmatched error.

## Success metric

The primary metric is first-attempt TradingView compile rate for unmodified scripts. Secondary metrics are visual correctness and time-to-repair.
