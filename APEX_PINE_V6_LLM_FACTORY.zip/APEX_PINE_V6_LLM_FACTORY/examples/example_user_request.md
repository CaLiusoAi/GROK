BUILD GOAL:
Create an overlay indicator that marks bullish and bearish EMA regime shifts.

SCRIPT TYPE:
indicator

ONE QUESTION THE SCRIPT ANSWERS:
Is the fast EMA above or below the slow EMA, and did the regime just change?

TIMEFRAME ASSUMPTIONS:
Works on the chart timeframe only. No MTF.

VISUAL OUTPUT:
Plot fast and slow EMAs, background tint for current regime, and one label only on the latest confirmed regime shift.

RESOURCE LIMITS:
labels <= 1, lines = 0, boxes = 0, tables = 0.

TRADING RULES OR FORMULAS:
Fast EMA length 21, slow EMA length 55 by default. Bullish regime is fast > slow. Bearish regime is fast < slow. Regime shift requires barstate.isconfirmed.

DO NOT INCLUDE:
No alerts in phase 1. No strategy orders.

BUILD MODE:
single-pass
