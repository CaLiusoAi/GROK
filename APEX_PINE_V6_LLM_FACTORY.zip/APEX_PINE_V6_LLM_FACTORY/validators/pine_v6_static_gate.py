#!/usr/bin/env python3
"""APEX Pine v6 static gate.

This does not compile Pine. TradingView remains the judge.
It catches common LLM-generated Pine v6 failures before paste-testing.
"""
from __future__ import annotations
import re, sys, json
from pathlib import Path

BANNED_SUBSTRINGS = {
    'line.style_none': 'Pine has no line.style_none. Do not draw, delete, or use a transparent color instead.',
    'str.hash': 'Pine v6 has no str.hash. Hashing must be external.',
    'sha256': 'Pine v6 has no SHA-256 API. Hashing must be external.',
    'sha1': 'Pine v6 has no SHA API. Hashing must be external.',
    'transp=': 'Use color.new(base, transparency) instead of transp=.',
    'color.emerald': 'Use color.rgb() or color.new(); do not invent color constants.',
    'color.gold': 'Use color.rgb() or color.new(); do not invent color constants.',
    'color.teal': 'Contract bans this constant. Use color.rgb() or color.new().',
    '“': 'Smart quote found. Use ASCII quotes.',
    '”': 'Smart quote found. Use ASCII quotes.',
    '‘': 'Smart quote found. Use ASCII quotes.',
    '’': 'Smart quote found. Use ASCII quotes.',
}

IF_NUMERIC_RE = re.compile(r'^\s*if\s+(close|open|high|low|volume|hl2|hlc3|ohlc4)\s*(?:$|//)')
SEMICOLON_RE = re.compile(r';\s*(?=\S)')
HANDLE_SET_RE = re.compile(r'\b([A-Za-z_]\w*)\.(set_[A-Za-z0-9_]+|delete)\s*\(')
GUARD_RE_TEMPLATE = r'not\s+na\s*\(\s*{name}\s*\)'
PLACEHOLDER_RE = re.compile(r'<[^>]+>|\[[^\]]*placeholder[^\]]*\]', re.I)


def strip_comments(line: str) -> str:
    return line.split('//', 1)[0]


def validate_text(text: str) -> list[dict]:
    findings=[]
    lines=text.splitlines()

    if not lines or not lines[0].strip().startswith('//@version=6'):
        findings.append({'severity':'error','line':1,'rule':'version_header','message':'First line should be //@version=6.'})

    header_blob='\n'.join(lines[:35])
    for field in ['IDENTITY','REQUEST','ANSWERS','DOES NOT','INPUTS','DETECTION','RESOURCE','INVARIANTS','LIMITS']:
        if field not in header_blob:
            findings.append({'severity':'error','line':1,'rule':'missing_header_field','message':f'Missing header field: {field}.'})
    if PLACEHOLDER_RE.search(header_blob):
        findings.append({'severity':'error','line':1,'rule':'placeholder','message':'Header appears to contain placeholders.'})

    for i,line in enumerate(lines, start=1):
        raw=line
        code=strip_comments(raw)
        low=raw.lower()
        for banned,msg in BANNED_SUBSTRINGS.items():
            if banned.lower() in low:
                findings.append({'severity':'error','line':i,'rule':'banned_token','token':banned,'message':msg})
        if SEMICOLON_RE.search(code):
            findings.append({'severity':'error','line':i,'rule':'semicolon','message':'One statement per line. Remove semicolon statement chaining.'})
        m=IF_NUMERIC_RE.match(code)
        if m:
            findings.append({'severity':'error','line':i,'rule':'numeric_if','message':f'if {m.group(1)} is not bool. Use an explicit comparison.'})

    # conservative handle guard scan: look back 3 lines for not na(handle)
    for i,line in enumerate(lines, start=1):
        code=strip_comments(line)
        for m in HANDLE_SET_RE.finditer(code):
            name=m.group(1)
            window='\n'.join(lines[max(0,i-4):i])
            if not re.search(GUARD_RE_TEMPLATE.format(name=re.escape(name)), window):
                findings.append({'severity':'warning','line':i,'rule':'unguarded_handle','message':f'{name}.{m.group(2)} appears without nearby not na({name}) guard.'})

    return findings


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print('Usage: python validators/pine_v6_static_gate.py path/to/script.pine')
        return 2
    path=Path(argv[1])
    text=path.read_text(encoding='utf-8')
    findings=validate_text(text)
    print(json.dumps({'file':str(path),'findings':findings,'error_count':sum(1 for f in findings if f['severity']=='error'),'warning_count':sum(1 for f in findings if f['severity']=='warning')}, indent=2))
    return 1 if any(f['severity']=='error' for f in findings) else 0

if __name__ == '__main__':
    raise SystemExit(main(sys.argv))
