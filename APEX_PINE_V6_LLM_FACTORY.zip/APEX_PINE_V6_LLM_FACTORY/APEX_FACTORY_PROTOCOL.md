# APEX Pine v6 LLM Factory Protocol

Purpose: make GPT, Gemini, Claude, Grok, or any other capable chat model produce Pine Script v6 with fewer hallucinated APIs, cleaner visual output, and a repeatable repair loop.

This is not a VS Code extension. VS Code is optional packaging. The product is the chat factory.

## Core operating rule

Every Pine build follows this loop:

1. Intake the user's goal.
2. Reduce the goal to one script question.
3. Run detection if chart, candle, image, pattern, or setup identification is involved.
4. Emit a full Pine v6 file with the required header inside the code block.
5. Run the static gate before handing code to the user.
6. Ask the user to paste into TradingView.
7. If TradingView returns an error, repair only from the compiler message and the current source.
8. Log result in the tracker.

No model may claim TradingView compile success unless the user actually reports it.

## Precedence stack

1. PINE_MASTER_SSD_v2_5 is the current live doctrine.
2. PINE_EMISSION_CONTRACT is the compact emission gate that must be enforced immediately before code output.
3. PINE_v6_ORACLE_v2_1 is the older interactive phased build protocol and remains useful for staged work.
4. Pine v6 reference files under knowledge/pine_v6_reference are local lookup material.
5. TradingView compiler overrides every document.

## Required output shape for code

Before a Pine code block, the model must output:

DETECTION CHECK: N/A or a numeric chart/candle conclusion.

SELF-CHECK: Header filled, 0 placeholders. Detection stated. Invariants listed. Static gate reviewed. Emitting now.

Then the code block begins with:

```pine
//@version=6
// ============================================================
// IDENTITY      : real name | indicator/strategy | date
// REQUEST       : one sentence
// ANSWERS       : the one question the script answers
// DOES NOT      : deliberate exclusions
// INPUTS        : all inputs
// DETECTION     : exact numeric rule or N/A
// RESOURCE      : labels=N lines=N boxes=N tables=N
// INVARIANTS    :
//   INV-01 request.security lookahead_off when used
//   INV-02 drawing handles var-init to na and guarded before set/delete
//   INV-03 if-conditions are explicit bool expressions
//   INV-04 no fictional APIs or enum members
//   INV-05 visual density is capped or toggled
//   INV-06 confirmed-bar gating where signals matter
//   INV-07 fail-closed behavior on missing data
// LIMITS        : not compiled in TradingView until user verifies
// ============================================================
```

## Hard Pine v6 bans

- No line.style_none.
- No str.hash, SHA, crypto hash, or pretend hash APIs.
- No transp= argument.
- No color.emerald, color.gold, color.teal, or invented color constants.
- No semicolon statement separators.
- No smart quotes.
- No if close, if open, if high, if low, if volume. Conditions must be bool.
- No drawing handle mutation or deletion unless guarded by not na(handle).
- No create-per-bar object spam for current-state objects. Create once, update in place.

## Phased build mode

Use phased mode for complex requests. Each phase emits the full cumulative file, not a patch fragment.

Phase 1: Scaffold, header, inputs, resource budget.
Phase 2: Data acquisition and detection.
Phase 3: Core calculations and plots.
Phase 4: Drawings, labels, tables, visual density.
Phase 5: Alerts or strategy behavior.
Phase 6: Static gate and compile-repair loop.

## Repair mode

When a user pastes a TradingView error:

1. Quote the exact error in plain text.
2. Identify the failing line or construct.
3. State the smallest correction.
4. Emit the full corrected script.
5. Do not rewrite unrelated sections.
6. Do not claim success until the user confirms.

## Model adapter notes

ChatGPT: use one pasted master prompt plus the current build request.
Claude: keep the contract near the final code emission because long context can dilute final-step rules.
Gemini: restate the hard bans immediately before code.
Grok: force the static gate and prohibit improvising Pine APIs.

## What this factory cannot do by itself

It cannot run TradingView's compiler. It cannot guarantee visual correctness without the user's chart. It cannot turn an underspecified trading idea into a profitable system. Humanity continues to demand miracles from autocomplete, but this package at least gives the autocomplete a guardrail.
