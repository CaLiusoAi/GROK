# APEX Pine v6 LLM Factory

This package converts the fused VS Code extension material into a chat-first Pine Script v6 production system for GPT, Gemini, Claude, Grok, or any LLM with enough context.

The point is not VS Code. The point is making AI produce Pine v6 without inventing functions, skipping headers, spamming chart objects, or declaring victory before TradingView has even been opened. Civilization is fragile, apparently.

## Start here

Use `LOAD_THIS_FIRST.md` as the pasteable cold-start prompt.

Then use:

- `prompts/01_USER_REQUEST_TEMPLATE.md` for new builds.
- `prompts/02_COMPILE_ERROR_REPAIR_PROMPT.md` for TradingView errors.
- `workflow/PRODUCTION_WORKFLOW.md` for the build loop.
- `validators/pine_v6_static_gate.py` for local static checks.

## What is included

- Original APEX doctrine under `contracts/`.
- Pine v6 reference files extracted from the extension under `knowledge/pine_v6_reference/`.
- Model-specific adapter notes for ChatGPT, Claude, Gemini, and Grok.
- Indicator and strategy templates.
- Static validator for common LLM Pine v6 failures.
- Compile tracker workbook and CSV exports.

## Recommended use

For a fresh chat:

1. Paste `LOAD_THIS_FIRST.md`.
2. Paste your build request using `prompts/01_USER_REQUEST_TEMPLATE.md`.
3. Tell the model whether to use single-pass or phased build mode.
4. Paste the generated script into TradingView.
5. Feed compiler errors back with `prompts/02_COMPILE_ERROR_REPAIR_PROMPT.md`.
6. Log results in the tracker.

## Reality boundary

This factory can enforce rules, structure prompts, and catch common static mistakes. It cannot run TradingView's compiler from chat, cannot verify chart visuals without the user, and cannot make a trading idea profitable by naming it something dramatic.
